from The_pattern import pattern_42
from D_F_S import dfs, N, E, S, W


class Cell:
    def __init__(self):
        self.walls = N | E | S | W
        self.visited = False
        self.pattern = False


def print_maze(maze, rows, cols):
    height = rows * 2 + 1
    width = cols * 4 + 1

    canvas = []
    for _ in range(height):
        canvas.append([" "] * width)

    for r in range(rows):
        for c in range(cols):
            cell = maze[r][c]

            y = r * 2
            x = c * 4

            canvas[y][x] = "█"
            canvas[y][x + 4] = "█"
            canvas[y + 2][x] = "█"
            canvas[y + 2][x + 4] = "█"

            if cell.walls & N:
                canvas[y][x + 1] = "█"
                canvas[y][x + 2] = "█"
                canvas[y][x + 3] = "█"

            if cell.walls & S:
                canvas[y + 2][x + 1] = "█"
                canvas[y + 2][x + 2] = "█"
                canvas[y + 2][x + 3] = "█"

            if cell.walls & W:
                canvas[y + 1][x] = "█"

            if cell.walls & E:
                canvas[y + 1][x + 4] = "█"

    for line in canvas:
        print("".join(line))


def creat_maze(rows, cols):
    Grid = []
    for _ in range(rows):
        row = []
        for _ in range(cols):
            row.append(Cell())
        Grid.append(row)
    pattern_42(Grid, rows, cols)
    dfs(Grid, 0, 0, rows, cols)
    print_maze(Grid, rows, cols)


def main():
    rows = int(input("Enter length of The maze : "))
    # rows = 7
    cols = int(input("Enter weigth of The maze : "))
    # cols = 9
    creat_maze(rows, cols)


main()
