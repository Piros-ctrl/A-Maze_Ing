def switch_cells_to_fald(grid, rows, cols):
    for r in rows:
        for c in cols:
            if grid[r][c].pattern:
                continue
            grid[r][c].visited = False


def generate_path(grid, x, y, ):
    if grid
